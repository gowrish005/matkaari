import React, { useRef, useState, useEffect } from 'react'
import { motion, useInView } from 'framer-motion'

const Menu = () => {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })
  const [menuItems, setMenuItems] = useState([])
  const [selectedCategory, setSelectedCategory] = useState('All')

  const categories = ['All', 'Chai & Coffee', 'Beverages', 'Pasta & Maggi', 'Momos & Bao', 'Sandwich', 'Pizza', 'Munchies']

  useEffect(() => {
    // Fetch and parse CSV
    fetch('/menu/menu-items.csv')
      .then(response => response.text())
      .then(data => {
        const lines = data.split('\n').slice(1) // Skip header
        const items = lines
          .filter(line => line.trim())
          .map(line => {
            const [name, description, price, image] = line.split(',')
            return {
              name: name?.trim(),
              description: description?.trim(),
              price: price?.trim(),
              image: `/menu/images/${image?.trim()}`,
              category: getCategoryFromName(name?.trim())
            }
          })
        setMenuItems(items)
      })
      .catch(error => console.error('Error loading menu:', error))
  }, [])

  const getCategoryFromName = (name) => {
    const nameLower = name?.toLowerCase() || ''
    if (nameLower.includes('chai') || nameLower.includes('coffee')) return 'Chai & Coffee'
    if (nameLower.includes('shake') || nameLower.includes('lassi') || nameLower.includes('lime')) return 'Beverages'
    if (nameLower.includes('pasta') || nameLower.includes('maggi')) return 'Pasta & Maggi'
    if (nameLower.includes('momo') || nameLower.includes('bao')) return 'Momos & Bao'
    if (nameLower.includes('sandwich')) return 'Sandwich'
    if (nameLower.includes('pizza')) return 'Pizza'
    return 'Munchies'
  }

  const filteredItems = selectedCategory === 'All' 
    ? menuItems 
    : menuItems.filter(item => item.category === selectedCategory)

  return (
    <section id="menu" className="py-20 md:py-32 overflow-hidden" style={{ backgroundColor: '#FFFFFF' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center space-y-6 mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full text-sm font-semibold" style={{ backgroundColor: '#E4A93E', color: '#FFFFFF' }}>
            Our Offerings
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold" style={{ color: '#B7410E' }}>
            OUR MENU
          </h2>
          <p className="max-w-2xl mx-auto" style={{ color: '#0E1326' }}>
            Discover our exquisite range served in traditional kulhads
          </p>
        </motion.div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className="px-6 py-3 rounded-full font-semibold transition-all duration-300 hover:scale-105"
              style={{
                backgroundColor: selectedCategory === category ? '#B7410E' : '#FFFFFF',
                color: selectedCategory === category ? '#FFFFFF' : '#0E1326',
                border: `2px solid ${selectedCategory === category ? '#B7410E' : '#E4A93E'}`
              }}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Menu Items Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
          {filteredItems.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              className="group relative"
            >
              <div className="relative rounded-3xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden" style={{ backgroundColor: '#FFFFFF', border: '2px solid #E4A93E' }}>
                {/* Image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    onError={(e) => {
                      e.target.style.display = 'none'
                      e.target.nextSibling.style.display = 'flex'
                    }}
                  />
                  {/* Fallback if image not found */}
                  <div className="hidden absolute inset-0 items-center justify-center text-6xl" style={{ backgroundColor: '#E4A93E' }}>
                    🏺
                  </div>
                </div>

                {/* Content */}
                <div className="p-4 space-y-2">
                  <h3 className="text-lg font-heading font-bold" style={{ color: '#0E1326' }}>
                    {item.name}
                  </h3>
                  <p className="text-sm line-clamp-2" style={{ color: '#0E1326', opacity: 0.7 }}>
                    {item.description}
                  </p>
                  <div className="flex items-center justify-between pt-2">
                    <span className="text-xl font-bold" style={{ color: '#B7410E' }}>
                      ₹{item.price}
                    </span>
                    <span className="px-3 py-1 rounded-full text-xs font-semibold" style={{ backgroundColor: '#E4A93E', color: '#FFFFFF' }}>
                      {item.category}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Special Note */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-16 text-center"
        >
          <div className="inline-flex items-center space-x-4 rounded-2xl px-8 py-6 shadow-xl" style={{ backgroundColor: '#FFFFFF', border: '2px solid #E4A93E' }}>
            <span className="text-4xl">🏺</span>
            <div className="text-left">
              <p className="text-lg font-semibold" style={{ color: '#0E1326' }}>
                Every Dish Served in Traditional Kulhads
              </p>
              <p className="text-sm" style={{ color: '#0E1326' }}>
                Celebrating the rich heritage of earthenware
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default Menu
